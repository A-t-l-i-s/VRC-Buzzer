from pathlib import Path

from ..Core.Object import *
from ..Core.Structure import *





__all__ = ("RFT_Config_Loader",)





class RFT_Config_Loader(RFT_Object):
	exts = ()



	def import_(cls, path:str):
		...

		



