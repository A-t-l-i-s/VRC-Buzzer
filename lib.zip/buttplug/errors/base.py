class ButtplugError(Exception):
    """Base class for all exceptions from this library."""
